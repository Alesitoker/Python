def mayor20(tupla):
    for i in tupla:
        if i > 20:
            print(i)

tupla = (22, 24, 10, 5, 16, 29, 190, 1, 18, 57)

mayor20(tupla)